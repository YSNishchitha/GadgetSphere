package com.gadget;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class GadgetSphereApplication {

	public static void main(String[] args) {
		SpringApplication.run(GadgetSphereApplication.class, args);
	}

}

