import { Component } from '@angular/core';

@Component({
  selector: 'app-indexfooter',
  templateUrl: './indexfooter.component.html',
  styleUrl: './indexfooter.component.css'
})
export class IndexfooterComponent {

}
