import { Component } from '@angular/core';

@Component({
  selector: 'app-adminhelp',
  templateUrl: './adminhelp.component.html',
  styleUrl: './adminhelp.component.css'
})
export class AdminhelpComponent {

}
