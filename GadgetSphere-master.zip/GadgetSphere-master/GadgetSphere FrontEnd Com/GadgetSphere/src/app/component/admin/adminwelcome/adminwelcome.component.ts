import { Component } from '@angular/core';

@Component({
  selector: 'app-adminwelcome',
  templateUrl: './adminwelcome.component.html',
  styleUrl: './adminwelcome.component.css'
})
export class AdminwelcomeComponent {

}
